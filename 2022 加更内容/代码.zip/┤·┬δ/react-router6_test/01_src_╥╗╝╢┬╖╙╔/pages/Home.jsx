import React from 'react'

export default function Home() {
	return (
		<h3>我是Home的内容</h3>
	)
}
